<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Frutas;
use App\Http\Resources\Frutas as FrutasResource;

class FrutasController extends Controller
{
   public function crear(Request $request)
   {
   		if($request->isMethod('post')){
   			$frutas = new Frutas; 
   			$frutas->name = $request->input('name');
   			$frutas->amount = $request->input('amount');
   			$frutas->price = $request->input('price');
   			
   			$frutas->save();
  
   		}
   }

   public function mostrar()
   {
   		$frutas = Frutas::paginate(20);
   		return $frutas;


   }

   public function eliminar($id)
    {
    	$frutas = Frutas::find($id);
  	 	$frutas->delete();
   
   	}

   	public function actualizar(Request $request,$id)
   	{
   		if($request->isMethod('put')){
   			$frutas = Frutas::find($id);
   		
   			$frutas->name = $request->input('name');
   			$frutas->amount = $request->input('amount');
   			$frutas->price = $request->input('price');
   			
   			$frutas->save();
  
   		}
   	}
}

